import 'package:http/http.dart' as http;

import '../models/todos.dart';



class TodosService {
  Future<List<Todos>> getTodos() async{
    var client = http.Client();
try {
  var response = await client.get(
      Uri.parse('https://jsonplaceholder.typicode.com/todos'));


  List<Todos> todos1 =  todosFromJson(response.body);
  return todos1;
      
} 

finally {
  client.close();
}
  }
}
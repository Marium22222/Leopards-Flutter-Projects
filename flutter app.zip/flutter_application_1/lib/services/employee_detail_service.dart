

import 'package:flutter_application_1/models/accounts.dart';
import 'package:flutter_application_1/models/employee_detail.dart';
import 'package:flutter_application_1/models/services.dart';
import 'package:http/http.dart' as http;



class EmployeeService {
  Future<EmployeeDetail?> getEmployeeDetail() async {
    var headers = {'ApiKey': 'Nr088oU9FRpaB1mshH0LWw=='};
    var params = {'EmpNo': '25216'};
    final uri = Uri.http(
        '172.16.0.63', '/EShipApi/api/EShip/getEmployeeDetail', params);

    var client = http.Client();
    try {
      var response = await client.get(uri, headers: headers);

      final variable1 = employeeDetailFromJson(response.body);
      return variable1;
    
    }
finally {
      client.close();
    }
    

  }
  //http://172.16.0.63/EShipApi/api/EShip/getCourierAccount?CityID=592


  //in future accounts class can have null values.

  
//future means that function will take time to complete thats why we use await when calling it
//
   Future<Accounts?> getAccounts(String cityID1) async {
    var headers = {'ApiKey': 'Nr088oU9FRpaB1mshH0LWw=='};
    var params = {'CityID': cityID1};
    final uri = Uri.http(
        '172.16.0.63', '/EShipApi/api/EShip/getCourierAccount', params);

    var client = http.Client();
    try {
      var response = await client.get(uri, headers: headers);

      final variable1 = accountsFromJson(response.body);
      return variable1;
    } finally {
      client.close();
    }

  }
  Future<Services?> getServices() async {
    var headers = {'ApiKey': 'Nr088oU9FRpaB1mshH0LWw=='};
 
    final uri = Uri.http(
        '172.16.0.63', '/EShipApi/api/EShip/getServiceType');

    var client = http.Client();
    try {
      var response = await client.get(uri, headers: headers);


      final variable1 = servicesFromJson(response.body);
      return variable1;
    } finally {
      client.close();
    }

  }

}

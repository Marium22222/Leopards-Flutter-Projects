import 'package:http/http.dart' as http;

import '../models/users.dart';



class UsersService {
  Future<List<Users>> getUsers() async{
    var client = http.Client();
try {
  var response = await client.get(
      Uri.parse('https://jsonplaceholder.typicode.com/users'));

  List<Users> users1 =  usersFromJson(response.body);
  return users1;
      
} 

finally {
  client.close();
}
  }
}
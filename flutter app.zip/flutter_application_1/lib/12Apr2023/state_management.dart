import 'package:flutter/material.dart';

import 'package:flutter_application_1/12Apr2023/user_widget.dart';
import 'package:flutter_application_1/controllers/users_controller.dart';
import 'package:get/get.dart';


class StateManagement extends StatefulWidget {
  const StateManagement({super.key});

  @override
  State<StateManagement> createState() => _StateManagementState();
}

class _StateManagementState extends State<StateManagement> {
  UsersController user1 = Get.put(UsersController());

  @override
  void initState() {
    super.initState();
    user1.getRandomUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo[200],
      appBar: AppBar(
        title: const Text('Details'),
        centerTitle: true,
        leading: const Icon(Icons.home),
        backgroundColor: Colors.green,
      ),
      body: Obx(() {
        return user1.loading.value
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Image.network(
                      'https://w.forfun.com/fetch/81/81997906b60e649b9f426b0a4c0dc05d.jpeg'),
                  Expanded(
                    child: ListView.builder(
                        itemCount: user1.usersList.length,
                        itemBuilder: (context, index) {
                          return UserWidget(
                              result: user1.usersList[index],
                              onRemove: () {
                                user1.usersList.removeAt(index);
                              });
                        }),
                  ),
                ],
              );
      }),
    );
  }
}

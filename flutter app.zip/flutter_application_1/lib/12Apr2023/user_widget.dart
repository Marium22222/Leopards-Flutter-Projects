
import 'package:flutter/material.dart';
import 'package:flutter_application_1/controllers/users_controller.dart';
import 'package:get/get.dart';

import '../models/random_user.dart';


class UserWidget extends StatefulWidget {
  final Result result;
  final Function() onRemove;
  const UserWidget({super.key, required this.result, required this.onRemove});

  @override
  State<UserWidget> createState() => _UserWidgetState();
}

class _UserWidgetState extends State<UserWidget> {
  String? description;
  String? value;
  int index=0;


  @override
  Widget build(BuildContext context) {
    return  SafeArea(
      child: SingleChildScrollView(
        child: GetX<UsersController>(
          builder: (controller) {
            controller.loading.value;
            return Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 5,
                          color: Colors.greenAccent
                        ),
                        borderRadius: BorderRadius.circular(50)
                      ),
                      child: CircleAvatar(
                        radius: 40,
                        backgroundImage: NetworkImage(widget.result.picture.large),),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                      Text(
                          description ?? "Hi, My Name is",
                      style: const TextStyle(
                        fontSize: 15,

                      ),
                        textAlign: TextAlign.center,

                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(textAlign:  TextAlign.center,
                    value ?? '${widget.result.name.first} ${widget.result.name.last} ',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                    ),),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                          description= "My Name is";
                          value = '${widget.result.name.first} ${widget.result.name.last}' ;
                          index=0;
                          setState(() {

                          });
                          },
                          child: Icon(Icons.account_box,
                          color: index==0 ? Colors.yellow : Colors.black,),
                        ),

                        GestureDetector(
                          onTap: (){
                            description= "My Email is";
                            value=widget.result.email;
                            index=1;
                            setState(() {

                            });
                          },
                          child:Icon(Icons.email,
                          color: index==1? Colors.yellow : Colors.black,) ,
                          //bd ,city, phone,pass
                        ),
                        GestureDetector(
                          onTap: (){
                            description= "My Birthday is";
                            value='${widget.result.dob.date}.'.substring(0,10);
                            index=2;
                            setState(() {

                            });
                          },
                          child:Icon(Icons.cake,
                            color: index==2? Colors.yellow : Colors.black,) ,
                          //bd ,city, phone,pass
                        ),
                        GestureDetector(
                          onTap: (){
                            description= "My Location is";
                            value='${widget.result.location.street.number} ${widget.result.location.street.name} ${widget.result.location.city}';
                            index=3;
                            setState(() {

                            });
                          },
                          child:Icon(Icons.location_city,
                            color: index==3? Colors.yellow : Colors.black,) ,
                          //bd ,city, phone,pass
                        ),
                        GestureDetector(
                          onTap: (){
                            description= "My Phone Number is";
                            value=widget.result.phone;
                            index=4;
                            setState(() {

                            });
                          },
                          child:Icon(Icons.phone,
                            color: index==4? Colors.yellow : Colors.black,) ,
                          //bd ,city, phone,pass
                        ),
                        GestureDetector(
                          onTap: (){
                            description= "My Password  is";
                            value='${widget.result.login.password} ';
                            index=5;
                            setState(() {

                            });
                          },
                          child:Icon(Icons.lock,
                            color: index==5? Colors.yellow : Colors.black,) ,
                          //bd ,city, phone,pass
                          //bd ,city, phone,pass
                        ),
                        GestureDetector(
                          onTap: (){
                            description= "My gender is";
                            value= '${widget.result.gender}'.substring(7);
                            index=6;
                            setState(() {

                            });
                          },
                          child: Icon(Icons.person,
                          color: index==6 ? Colors.yellow : Colors.black,),

                        ),
                        GestureDetector(
                          // onTap: widget.onRemove,
                          onTap:() {
                            controller.usersList.removeWhere((element) =>element== widget.result);

                          },
                          child: Icon(Icons.delete,
                          color: index==7 ? Colors.yellow : Colors.black,),

                        )

                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  const Divider(
                      height: 20,
                      color: Colors.green,
                      thickness: 2,
                    )

                  ],
                );
          }
        ),
      ),
    );


  }
}

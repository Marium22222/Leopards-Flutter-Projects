import 'package:http/http.dart' as http;

import '../models/random_user.dart';

class RandomService {
  Future<RandomUser> getRandomService() async{
    var client = http.Client();
    try {
      var response = await client.get(
          Uri.parse('https://randomuser.me/api/?results=10'));

      RandomUser random1 =  randomUserFromJson(response.body);
      return random1;

    }

    finally {
      client.close();
    }
  }
}
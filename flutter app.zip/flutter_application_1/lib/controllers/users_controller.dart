import 'package:flutter_application_1/12Apr2023/random_service.dart';
import 'package:flutter_application_1/models/random_user.dart';
import 'package:get/get.dart';

class UsersController extends GetxController {
  RandomService service2 = RandomService();
  //obs ki waja se reactive ya observable hgya hai.
  var usersList = <Result>[].obs;
  var loading = true.obs;
  void getRandomUser() async {
    RandomUser random1 = await service2.getRandomService();
    usersList.addAll(random1.results);
    loading.value = false;
  }
}

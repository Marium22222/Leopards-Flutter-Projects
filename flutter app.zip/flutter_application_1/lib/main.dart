import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/screens/home.dart';
import 'package:get/get.dart';
import 'firebase/firebase_example.dart';
import 'firebase/firebase_form.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
 await Firebase.initializeApp();
  runApp( GetMaterialApp(
    // theme: ThemeData(appBarTheme:AppBarTheme(backgroundColor:Colors.amber ) ,
    // textTheme: TextTheme(displayLarge: TextStyle(color: Colors.white,
    // fontSize: 18,
    // fontWeight: FontWeight.normal))),
    home: Home(),
  ));
}

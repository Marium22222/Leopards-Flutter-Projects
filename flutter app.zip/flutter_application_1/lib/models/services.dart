// To parse this JSON data, do
//
//     final services = servicesFromJson(jsonString);

import 'dart:convert';

Services servicesFromJson(String str) => Services.fromJson(json.decode(str));

String servicesToJson(Services data) => json.encode(data.toJson());

class Services {
    Services({
        required this.status,
        required this.data,
    });

    int status;
    List<ServicesDetail> data;

    factory Services.fromJson(Map<String, dynamic> json) => Services(
        status: json["Status"],
        data: List<ServicesDetail>.from(json["Data"].map((x) => ServicesDetail.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "Status": status,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class ServicesDetail {
    ServicesDetail({
        required this.shipmentCodeId,
        required this.shipmentType,
        required this.code,
        required this.geoAreaType,
        required this.bookTypeId,
        required this.bookTypeDscrp,
    });

    int shipmentCodeId;
    String shipmentType;
    String code;
    String geoAreaType;
    int bookTypeId;
    String bookTypeDscrp;

    factory ServicesDetail.fromJson(Map<String, dynamic> json) =>ServicesDetail(
        shipmentCodeId: json["shipment_code_id"],
        shipmentType: json["shipment_type"],
        code: json["code"],
        geoAreaType: json["geo_area_type"],
        bookTypeId: json["book_type_id"],
        bookTypeDscrp: json["book_type_dscrp"],
    );

    Map<String, dynamic> toJson() => {
        "shipment_code_id": shipmentCodeId,
        "shipment_type": shipmentType,
        "code": code,
        "geo_area_type": geoAreaType,
        "book_type_id": bookTypeId,
        "book_type_dscrp": bookTypeDscrp,
    };
}

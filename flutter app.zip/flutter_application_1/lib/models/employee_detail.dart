// To parse this JSON data, do
//
//     final employeeDetail = employeeDetailFromJson(jsonString);

import 'dart:convert';

EmployeeDetail employeeDetailFromJson(String str) => EmployeeDetail.fromJson(json.decode(str));

String employeeDetailToJson(EmployeeDetail data) => json.encode(data.toJson());

class EmployeeDetail {
    EmployeeDetail({
        required this.status,
        required this.isTokenUpdated,
        required this.data,
    });

    int status;
    int isTokenUpdated;
    List<Datum> data;

    factory EmployeeDetail.fromJson(Map<String, dynamic> json) => EmployeeDetail(
        status: json["Status"],
        isTokenUpdated: json["IsTokenUpdated"],
        data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "Status": status,
        "IsTokenUpdated": isTokenUpdated,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class Datum {
    Datum({
        required this.empNo,
        required this.name,
        required this.gender,
        required this.contact,
        required this.cityId,
        required this.cityName,
        required this.zoneId,
        required this.zone,
        required this.courierNo,
        required this.designation,
        required this.department,
        required this.photo,
        required this.isPickup,
        required this.isEShip,
        required this.locationId,
        required this.locationName,
    });

    String empNo;
    String name;
    String gender;
    String contact;
    String cityId;
    String cityName;
    String zoneId;
    String zone;
    String courierNo;
    String designation;
    String department;
    String photo;
    int isPickup;
    int isEShip;
    String locationId;
    String locationName;

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        empNo: json["EMP_NO"],
        name: json["NAME"],
        gender: json["GENDER"],
        contact: json["Contact"],
        cityId: json["CityID"],
        cityName: json["CityName"],
        zoneId: json["ZoneID"],
        zone: json["Zone"],
        courierNo: json["CourierNo"],
        designation: json["Designation"],
        department: json["Department"],
        photo: json["photo"],
        isPickup: json["IsPickup"],
        isEShip: json["IsEShip"],
        locationId: json["LocationID"],
        locationName: json["LocationName"],
    );

    Map<String, dynamic> toJson() => {
        "EMP_NO": empNo,
        "NAME": name,
        "GENDER": gender,
        "Contact": contact,
        "CityID": cityId,
        "CityName": cityName,
        "ZoneID": zoneId,
        "Zone": zone,
        "CourierNo": courierNo,
        "Designation": designation,
        "Department": department,
        "photo": photo,
        "IsPickup": isPickup,
        "IsEShip": isEShip,
        "LocationID": locationId,
        "LocationName": locationName,
    };
}

// To parse this JSON data, do
//
//     final accounts = accountsFromJson(jsonString);

import 'dart:convert';

Accounts accountsFromJson(String str) => Accounts.fromJson(json.decode(str));

String accountsToJson(Accounts data) => json.encode(data.toJson());

class Accounts {
    Accounts({
        required this.status,
        required this.data,
    });

    int status;
    List<AccountDetails> data;

    factory Accounts.fromJson(Map<String, dynamic> json) => Accounts(
        status: json["Status"],
        data: List<AccountDetails>.from(json["Data"].map((x) => AccountDetails.fromJson(x))),
    );
    
    Map<String, dynamic> toJson() => {
        "Status": status,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class AccountDetails {
    AccountDetails({
        required this.clntId,
        required this.clntName,
        required this.contactPerson,
        required this.contact,
        required this.address,
        required this.email,
    });

    String clntId;
    String clntName;
    String contactPerson;
    String contact;
    String address;
    String email;

    factory AccountDetails.fromJson(Map<String, dynamic> json) => AccountDetails(
        clntId: json["CLNT_ID"],
        clntName: json["CLNT_NAME"],
        contactPerson: json["ContactPerson"],
        contact: json["Contact"],
        address: json["ADDRESS"],
        email: json["Email"],
    );

    Map<String, dynamic> toJson() => {
        "CLNT_ID": clntId,
        "CLNT_NAME": clntName,
        "ContactPerson": contactPerson,
        "Contact": contact,
        "ADDRESS": address,
        "Email": email,
    };
}

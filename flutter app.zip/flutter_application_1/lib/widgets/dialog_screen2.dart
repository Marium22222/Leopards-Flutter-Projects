import 'package:flutter/material.dart';


class DialogueScreen2 extends StatelessWidget {
 final String username;
 final String name;
 final String website;
 final String city;
 final String street;
 final String phone;
 final String email;
 final int id;

  const DialogueScreen2({super.key,
  required this.username,
    required this.name,
    required this.email,
    required this.website,
    required this.id,
    required this.street,
    required this.phone,
    required this.city,

  });

  @override
  Widget build(BuildContext context) {
    return Center(

      child: Material(

        child: Padding(
          padding:  const EdgeInsets.all(8),
          child: Column(
            mainAxisSize: MainAxisSize.min,


            children: [
              Container(
                color: Colors.purple,
                child: Column(children: [
                  Row(
                children:  const [
                       Icon(Icons.list,
                       color: Colors.white,),
                ],
              ),

               const CircleAvatar(
                backgroundImage: AssetImage('assets/images/user3.jpg'),
                radius: 35,)
                ,
                  const  SizedBox(height: 20,),
                Text(
                  name,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight:FontWeight.bold,
                  color: Colors.white,

                ),),
                const SizedBox(height: 20,),
                TextButton(onPressed: (){},
              style: TextButton.styleFrom(

                shape: RoundedRectangleBorder(side: const BorderSide(color: Colors.white,width: 3,),
                borderRadius: BorderRadius.circular(20),),
              ),
                child: const Text('EDIT PROFILE',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight:FontWeight.bold,
                    color: Colors.white,

                ),),
                ),
                ]),
              ),
          const SizedBox(height: 20,),
          Container(

            color: Colors.white,
          child:   Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('ID'
                ,
                style:TextStyle(fontSize: 10),),
             Text("$id"
                ,
                style: const TextStyle(fontSize: 12,
                    fontWeight: FontWeight.bold),),
              const SizedBox(height: 10,),
                const Text('Username',
                style: TextStyle(fontSize: 10),),
              Text(username
                ,
                style: const TextStyle(fontSize: 12,
                fontWeight: FontWeight.bold),),
              const SizedBox(height: 10,),
              const Text('Fullname',
                style: TextStyle(fontSize: 10),),
              Text(name
                ,
                style: const TextStyle(fontSize: 12,
                    fontWeight: FontWeight.bold),),
              const SizedBox(height: 10,),

                const Text('Website'
                ,
                style: TextStyle(fontSize: 10),),
                Text(website
                ,
                style: const TextStyle(fontSize: 12,
                   fontWeight: FontWeight.bold),),
                const SizedBox(height: 10,),

               const Text('Phone'
                ,
                style:TextStyle(fontSize: 10),),
               Text(phone
                ,
                style: const TextStyle(fontSize: 12,
                   fontWeight: FontWeight.bold),),
                const SizedBox(height: 10,),

                const Text('City'
                ,
                style:TextStyle(fontSize: 10),),
                Text(city
                ,
                style: const TextStyle(fontSize: 12,
                   fontWeight: FontWeight.bold),),
                const SizedBox(height: 10),

                 const Text('Street'
                ,
                style:TextStyle(fontSize: 10),),
                Text(street
                ,
                style:const TextStyle(fontSize: 12,
                fontWeight: FontWeight.bold),),
                const SizedBox(height: 10,),

                 const Text('Email'
                ,
                style:  TextStyle(fontSize: 10),),
                Text(email
                ,
                style: const TextStyle(fontSize: 12,
                   fontWeight: FontWeight.bold),),
                const SizedBox(height: 10,),


             ],)
            ),
          ],),

          ),


      ),
    );
  }
}
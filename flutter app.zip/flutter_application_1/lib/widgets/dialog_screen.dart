import 'package:flutter/material.dart';

class DialogueScreen extends StatefulWidget {
  const DialogueScreen({super.key});

  @override
  State<DialogueScreen> createState() => _DialogueScreenState();
}

class _DialogueScreenState extends State<DialogueScreen> {
 bool ischecked=false;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
        
                children: [
                  const Expanded(
                    child: Text(
                      'SHIPMENT DETAILS',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                  ),
                  ElevatedButton(onPressed: () {}, child: const Text('OK')),
                  const SizedBox(width: 10,),
                  ElevatedButton(
                    onPressed: () {},
                    child: const Text('X'),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                
                children: const [
                  Flexible(
                  flex: 2,
                 
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Enter Destination',
                      ),
        
                    ),
                  ),
                  Flexible(
                    flex: 1,
                     child: TextField(
                      decoration: InputDecoration(
                        hintText: '250'),
                    ),
                  ),
               Flexible(
                    flex: 1,
                     child: TextField(
                      decoration: InputDecoration(
                        hintText: '1'),
                    ),
                  ),
                   Flexible(
                    flex: 1,
                    child: Icon(Icons.dangerous),),
                ],
              ),
             
              Row(
                children: const [
                       SizedBox(
                    width: 350,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Consignee Name'),
                    ),),
              ],),
                   
              Row(
                children: const [
                       SizedBox(
                    width: 350,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Reference No.'),
                    ),),
              ],),
              Row(
                children: const [
                       SizedBox(
                    width: 350,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Consignee Address 1.'),
                    ),),
              ],),
              Row(
                children: const [
                       SizedBox(
                    width: 350,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Consignee Address 2.'),
                    ),),
              ],),
              Row(
                children: const [
                  Text('Upload Image',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),),
                ],
              ),
              Row(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                
                    color: Colors.grey,
                    child: const Icon(Icons.camera),
                  ),
                ],
              ),
              Row(
                children: [
                  Checkbox(
              checkColor: Colors.white,
              value: ischecked,
              onChanged: (bool? value) {
               setState(() {
           ischecked = !ischecked;
               });
              },),
              const Text('Local'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

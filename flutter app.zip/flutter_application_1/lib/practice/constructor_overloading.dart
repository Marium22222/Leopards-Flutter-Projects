class Person{
final String name;
final int age;
final double height;
final double salary;

//image.asset is named constructor 
//we do not have default constructor in named constructor bcoz it is not called when 
//we have named constructor.
Person(this.name,this.age,this.height,this.salary);
Person.sal(int empid,this.name,this.age,this.height,this.salary);
String get getName => name;
int get getAge => age;
double get getHeight => height;
double get getSalary => salary;

}
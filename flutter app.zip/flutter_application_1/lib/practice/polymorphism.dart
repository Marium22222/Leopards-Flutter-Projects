
// ignore_for_file: unused_local_variable

import 'package:flutter/material.dart';


class Polymorphism extends StatefulWidget {
  const Polymorphism({super.key});

  @override
  State<Polymorphism> createState() => _PolymorphismState();
}
//optional and required parameters 
//optional has 2 types 1 is named and 1 other is there.
//dart has no option of method overloading so
class _PolymorphismState extends State<Polymorphism> {
  //v3 is optional or named parameter and v1 and v2 are required or positional parameters.
  //? then null allowed when required keyword then no nulls allowed.
 dynamic add(int v1,int v2,{required double v3}){
 // ignore: unnecessary_null_comparison
 if(v3 != null){
  return v1+v2+v3;
 }
 else {
    return v1+v2;
 }
  }
  void function2(){
   dynamic v4= add(1,3,v3:8.9);

  }
  @override
  Widget build(BuildContext context) {
    function2();
    return const Scaffold();
    //dead coded. return k bad code run nhi hota.
    // function2();
  }
}
import 'package:flutter/material.dart';

import 'package:flutter_application_1/shoppingApp/controller_shopping.dart';
import 'package:get/get.dart';

class ShoppingScreen extends StatefulWidget {
  const ShoppingScreen({super.key});

  @override
  State<ShoppingScreen> createState() => _ShoppingScreenState();
}

class _ShoppingScreenState extends State<ShoppingScreen> with AutomaticKeepAliveClientMixin  {
  ShoppingController controller1 = Get.put(ShoppingController());
  final input1 = TextEditingController();

  @override
  void initState() {

    super.initState();
    input1.text = "search";
    controller1.getShoppingService1();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        leading: const Icon(Icons.home),
        centerTitle: true,
      ),
      body: Column(children: [
        Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.grey, width: 5),
              borderRadius: BorderRadius.circular(20)),
          margin: const EdgeInsets.all(10),
          child: Row(
            children: [
              const Icon(Icons.search),
              Expanded(
                child: TextField(
                  controller: input1,
                ),
              ),
              const Icon(
                Icons.camera,
                color: Colors.green,
              )
            ],
          ),
        ),
        const Text(
          'Categories',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
             
              },
              child: const Icon(Icons.phone_android),
            ),
            const SizedBox(
              width: 2,
            ),
            GestureDetector(
              onTap: ()
              {
        
              },
              child: const Icon(Icons.laptop),
            ),
            const SizedBox(
              width: 2,
            ),
            GestureDetector(
              onTap: () {
   
                },
              child: const Icon(Icons.shopping_bag),
            ),
            const SizedBox(
              width: 2,
            ),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: const [
             Text(
              'Selling Brands',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  fontFamily: "Times New Roman"),
            ),

          ],
        ),
        Expanded(
          child: GetX<ShoppingController>(
            builder: (controller) {
              return ListView.builder(
                  itemCount: controller.shopList.length,
                  itemBuilder: ((context, index) {
                    return Column(

                      children: [
                        Text(controller.shopList[index].category
                          ),
                        Text(

                          controller.shopList[index].brand,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                            width: 200,
                            height: 200,
                            child: Image.network(
                                controller.shopList[index].images[0])),
                        Center(
                            child:
                                Text(controller.shopList[index].description)),
                    Text('${controller.shopList[index].price} Dollars',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.italic),),
                       ElevatedButton.icon(onPressed: (){
                         controller.cartList.add(controller.shopList[index]);
                  
                       },

                           icon: const Icon(Icons.shopping_cart),
                           label: const Text('Add to Cart'),),
                       
                        const Divider(
                          height: 10,
                          thickness: 5,
                          color: Colors.black,
                        )
                      ],
                    );
                  }));
            }
          ),
        )
      ]),
    );
  }
  
  @override
  bool get wantKeepAlive => true;
}

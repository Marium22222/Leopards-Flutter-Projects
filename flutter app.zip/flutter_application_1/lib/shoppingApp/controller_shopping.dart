import 'package:flutter_application_1/shoppingApp/shopping_service.dart';
import 'package:flutter_application_1/shoppingApp/shopping_model1.dart';
import 'package:get/get.dart';

class ShoppingController extends GetxController{
ShoppingService shopservice1 = ShoppingService();
var shopList =<Product>[].obs;
var cartList =<Product>[].obs;
var categoryList= <Product>[].obs;
var phoneList= <Product>[].obs;
var laptopList= <Product>[].obs;
var groceryList= <Product>[].obs;
var fragList=<Product>[].obs;
var skinList=<Product>[].obs;
var homedecList=<Product>[].obs;


var loading = true.obs;
void getShoppingService1() async{
  Shopping shop1 =await shopservice1.getShoppingService();
  shopList.addAll(shop1.products);
  phoneList.addAll(shop1.products.where((element) => element.category=="smartphones"));
  laptopList.addAll(shop1.products.where((element) => element.category=="laptops"));
  groceryList.addAll(shop1.products.where((element) => element.category=="groceries"));
    fragList.addAll(shop1.products.where((element) => element.category=="fragrances"));
    skinList.addAll(shop1.products.where((element) => element.category=="skincare"));
    homedecList.addAll(shop1.products.where((element) => element.category=="home-decoration"));

  loading.value=false;
}

}
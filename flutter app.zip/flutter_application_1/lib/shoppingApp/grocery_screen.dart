import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/shoppingApp/controller_shopping.dart';

class Grocery extends StatefulWidget {
  const Grocery({Key? key}) : super(key: key);

  @override
  State<Grocery> createState() => _GroceryState();
}

class _GroceryState extends State<Grocery> with AutomaticKeepAliveClientMixin {
  ShoppingController controller1 =Get.put(ShoppingController());
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('GROCERY'),
        leading: const Icon(Icons.android_sharp),
        centerTitle: true,

      ),
      body: ListView.builder(
        itemCount: controller1.groceryList.length,
          itemBuilder: (context,index){
            
          return Column(
            
            children: [
            
              Text(
      
                controller1.groceryList[index].brand,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
                  Text(
      
                controller1.groceryList[index].title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                  width: 200,
                  height: 200,
                  child: Image.network(
                      controller1.groceryList[index].images[0])),
              Center(
                  child:
              Text(controller1.groceryList[index].description)),
              Text('${controller1.groceryList[index].price} Dollars',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic),),
                    const Divider(
                      height: 4,
                      thickness: 5,
                    )
            ],
          );
      
      }),
    );
  }
  
  @override

  bool get wantKeepAlive => true;
}

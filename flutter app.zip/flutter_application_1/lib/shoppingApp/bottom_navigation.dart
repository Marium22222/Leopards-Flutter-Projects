import 'package:flutter/material.dart';

import 'package:flutter_application_1/shoppingApp/cart_screen.dart';
import 'package:flutter_application_1/shoppingApp/frag_screen.dart';
import 'package:flutter_application_1/shoppingApp/grocery_screen.dart';
import 'package:flutter_application_1/shoppingApp/home_screen.dart';
import 'package:flutter_application_1/shoppingApp/phone_screens.dart';

class BottomNavigation1 extends StatefulWidget {
  const BottomNavigation1({super.key});

  @override
  State<BottomNavigation1> createState() => _BottomNavigation1State();
}

class _BottomNavigation1State extends State<BottomNavigation1> {
  PageController controller2 = PageController(
    initialPage: 0
  );
  int _currentIndex =0;

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: controller2,
        children: const [
          ShoppingScreen(),
          CartScreen(),
          Phones(),
          Grocery(),
          Fragrances(),
          
        ],
      
      ),
      bottomNavigationBar: BottomNavigationBar
    
        (
        onTap: (value){
          if(value==0){
            setState(() {
              _currentIndex=value;
            });
            controller2.animateToPage(value, duration: const Duration(milliseconds: 300), curve: Curves.ease);
          }
          if(value==1){
            setState(() {
              _currentIndex=value;
            });
            controller2.animateToPage(value, duration: const Duration(milliseconds: 300), curve: Curves.ease);
          }
          if(value==2){
            setState(() {
              _currentIndex=value;
            });
            controller2.animateToPage(value, duration: const Duration(milliseconds: 300), curve: Curves.ease);
          }
          if(value==3){
            setState(() {
              _currentIndex=value;
            });
            controller2.animateToPage(value, duration: const Duration(milliseconds: 300), curve: Curves.ease);
          }
          if(value==4){
            setState(() {
              _currentIndex=value;
            });
            controller2.animateToPage(value, duration: const Duration(milliseconds: 300), curve: Curves.ease);
          }
        },
        
          currentIndex: _currentIndex,
          fixedColor:Colors.white,

          items: const [
            
        
        BottomNavigationBarItem(icon: Icon(Icons.home),
        label: 'Home',
        backgroundColor: Colors.black,
        ),
            
        BottomNavigationBarItem(icon: Icon(Icons.shopping_cart),
        label: 'Cart',
        backgroundColor: Colors.black),
            
        BottomNavigationBarItem(icon: Icon(Icons.android_sharp),
        label: 'Phones'
        ,
        backgroundColor: Colors.black
        ),
        BottomNavigationBarItem(icon: Icon(Icons.local_grocery_store_rounded),
        label: 'Grocery'
        ,
        backgroundColor: Colors.black),
        BottomNavigationBarItem(icon: Icon(Icons.smoke_free),
        label: 'Fragrances'
        ,
        backgroundColor: Colors.black),
        
      ]

      ),
      
    );
  }
}
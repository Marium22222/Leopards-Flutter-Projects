import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/shoppingApp/controller_shopping.dart';

class CartScreen extends StatefulWidget {


  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> with AutomaticKeepAliveClientMixin {

final controller2=Get.find<ShoppingController>();


  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      appBar: AppBar(
        title: const  Text('Cart'),
        centerTitle: true,
        leading: const  Icon(Icons.shopping_cart),
      ),
   body : Obx(
     (){
      // ignore: invalid_use_of_protected_member
      controller2.cartList.value;
     return ListView.builder(
      
      itemBuilder: (context,index){
 

      return Column(
        children:[
          Text(
            controller2.cartList[index].brand,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(
              width: 200,
              height: 200,
              child: Image.network(
                  controller2.cartList[index].images[0])),
          Center(
              child:

              Text(controller2.cartList[index].description)),
          Text('Quantity: ${controller2.cartList[index].quantity}' ),
            
          // Text('${controller2.cartList[index].price}*${quantity} Dollars',
          //   style: TextStyle(
          //       fontWeight: FontWeight.bold,
          //       fontStyle: FontStyle.italic),),
          Text('${controller2.cartList[index].price*controller2.cartList[index].quantity}',
            style:  const TextStyle(
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic),),

          ElevatedButton.icon(onPressed: (){
            controller2.cartList.removeAt(index);
           
          }, icon:  const Icon(Icons.delete), label:  const Text(
              'Remove'
          )),
          ElevatedButton.icon(onPressed: (){

              controller2.cartList[index].quantity+=1;
            controller2.cartList.refresh();
            
          
          }, icon: const  Icon(Icons.add), label:  const Text(
              'Add'
          )),

          ElevatedButton.icon(onPressed: (){

            if(controller2.cartList[index].quantity==1){
              controller2.cartList.removeAt(index);
            }
            else{
          controller2.cartList[index].quantity -= 1;
           controller2.cartList.refresh();
            }

         
           
          }, icon: const  Icon(Icons.remove), label: const  Text('decrease')),

          const  Divider(
            height: 10,
            thickness: 5,
            color: Colors.black,
          ),
        ],
      );
    },
    itemCount: controller2.cartList.length,
     );
   }),
    );
  }
  
  @override

  bool get wantKeepAlive => true;
}
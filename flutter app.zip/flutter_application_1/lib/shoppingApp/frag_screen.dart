import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/shoppingApp/controller_shopping.dart';

class Fragrances extends StatefulWidget {
  const Fragrances({Key? key}) : super(key: key);

  @override
  State<Fragrances> createState() => _FragrancesState();
}

class _FragrancesState extends State<Fragrances> with AutomaticKeepAliveClientMixin {
  ShoppingController controller1 =Get.put(ShoppingController());
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('FRAGRANCES'),
        leading: const Icon(Icons.android_sharp),
        centerTitle: true,

      ),
      body: ListView.builder(
        itemCount: controller1.fragList.length,
          itemBuilder: (context,index){
            
          return Column(
            
            children: [
            
              Text(
      
                controller1.fragList[index].brand,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
                  Text(
      
                controller1.fragList[index].title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                  width: 200,
                  height: 200,
                  child: Image.network(
                      controller1.fragList[index].images[0])),
              Center(
                  child:
              Text(controller1.fragList[index].description)),
              Text('${controller1.fragList[index].price} Dollars',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic),),
                    const Divider(
                      height: 4,
                      thickness: 5,
                    )
            ],
          );
      
      }),
    );
  }
  
  @override
  bool get wantKeepAlive => true;
}

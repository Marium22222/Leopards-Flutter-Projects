import 'package:flutter_application_1/shoppingApp/shopping_model1.dart';
import 'package:http/http.dart' as http;


class ShoppingService {
  Future<Shopping> getShoppingService() async{
    var client = http.Client();
    try {
      var response = await client.get(
          Uri.parse('https://dummyjson.com/products'));

      Shopping random1 = shoppingFromJson(response.body);
      return random1;

    }

    finally {
      client.close();
    }
  }
}
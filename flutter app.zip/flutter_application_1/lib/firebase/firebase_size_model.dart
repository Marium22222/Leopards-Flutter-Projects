// To parse this JSON data, do
//
//     final size = sizeFromJson(jsonString);

import 'dart:convert';

Size1 sizeFromJson(String str) => Size1.fromJson(json.decode(str));

String sizeToJson(Size1 data) => json.encode(data.toJson());

class Size1 {
    Size1({
        required this.screenWidth,
        required this.screenheight,
    });

    String screenWidth;
    String screenheight;

    factory Size1.fromJson(Map<String, dynamic> json) => Size1(
        screenWidth: json["ScreenWidth"],
        screenheight: json["Screenheight"],
    );

    Map<String, dynamic> toJson() => {
        "ScreenWidth": screenWidth,
        "Screenheight": screenheight,
    };
}

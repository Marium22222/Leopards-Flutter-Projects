import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SizeWidget extends StatefulWidget {
  Map<String, dynamic> data1;
  final int length1;
  final CollectionReference collectionReference;
  SizeWidget(
      {super.key,
      required this.collectionReference,
      required this.data1,
      required this.length1});

  @override
  State<SizeWidget> createState() => _SizeWidgetState();
}

class _SizeWidgetState extends State<SizeWidget> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Object?>> //it has list of documents
        (
        stream: widget.collectionReference.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.data == null || snapshot.hasError) {
            return const Center(child: Text("data not available"));
          }
          //data can be null.
          DocumentSnapshot doc2 = snapshot.data!.docs.first;
          Map<String, dynamic> data = doc2.data() as Map<String, dynamic>;
          return GestureDetector(
            onTap: () async {
              await widget.collectionReference.parent!.parent
                  .doc('NewID-${widget.length1 + 1}')
                  .set(widget.data1);
              widget.collectionReference.parent!.parent
                  .doc('NewID-${widget.length1}')
                  .collection("Size")
                  .doc()
                  .set(data);
            },
            child: Column(
              children: [
                Text('width ${data['ScreenWidth']}'),
                Text('height ${data['Screenheight']}'),
              ],
            ),
          );
        });
  }
}

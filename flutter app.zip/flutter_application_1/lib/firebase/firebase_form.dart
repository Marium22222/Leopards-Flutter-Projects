import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import 'firebase_mobile_model.dart';
import 'firebase_size_model.dart';

class FirebaseForm extends StatefulWidget {
  const FirebaseForm({super.key});

  @override
  State<FirebaseForm> createState() => _FirebaseFormState();
}

class _FirebaseFormState extends State<FirebaseForm> {
  final titleController =TextEditingController();
    final titleController1 =TextEditingController();
      final titleController2 =TextEditingController();
        final titleController3 =TextEditingController();
          final titleController4 =TextEditingController();
            final titleController5 =TextEditingController();
              final titleController6 =TextEditingController();

  @override

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Form"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(children: [
          //row me expanded use krte
          TextField(
      
            controller: titleController,
            decoration: InputDecoration(hintText: "Enter brand"),
          ),
           TextField(
      
            controller: titleController1,
            decoration: InputDecoration(hintText: "Enter price"),
          ),
           TextField(
      
            controller: titleController2,
            decoration: InputDecoration(hintText: "Enter title"),
          ), 
          TextField(
      
            controller: titleController3,
            decoration: InputDecoration(hintText: "Enter description"),
          ),
           TextField(
      
            controller: titleController4,
            decoration: InputDecoration(hintText: "Enter Screen width"),
          ),
          TextField(
      
            controller: titleController5,
            decoration: InputDecoration(hintText: "Enter Screen height"),
          ),
          TextField(
      
            controller: titleController6,
            decoration: InputDecoration(hintText: "Enter Image Url"),
          ),
          ElevatedButton(onPressed: (){
            sendDatatoFirebase();
          }, child: Text("submit"))
        ]),
      ),
    );
  }
  void  sendDatatoFirebase() async{
    Mobile mob1=Mobile(description:titleController3.text , image:titleController6.text, 
    price: int.parse(titleController1.text), brand: titleController.text, title: titleController2.text);
    Size1 size1 =Size1(screenWidth: titleController4.text, screenheight: titleController5.text);
    
    var ID1= FirebaseFirestore.instance.collection('Products').doc();
    await ID1.set(mob1.toJson()) ;
    ID1.collection("Size").doc().set(size1.toJson());

}
}
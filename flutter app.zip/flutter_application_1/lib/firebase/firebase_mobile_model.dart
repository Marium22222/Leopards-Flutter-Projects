// To parse this JSON data, do
//
//     final mobile = mobileFromJson(jsonString);

import 'dart:convert';

Mobile mobileFromJson(String str) => Mobile.fromJson(json.decode(str));

String mobileToJson(Mobile data) => json.encode(data.toJson());

class Mobile {
    Mobile({
        required this.description,
        required this.image,
        required this.price,
        required this.brand,
        required this.title,
    });

    String description;
    String image;
    int price;
    String brand;
    String title;

    factory Mobile.fromJson(Map<String, dynamic> json) => Mobile(
        description: json["Description"],
        image: json["Image"],
        price: json["Price"],
        brand: json["brand"],
        title: json["title"],
    );

    Map<String, dynamic> toJson() => {
        "Description": description,
        "Image": image,
        "Price": price,
        "brand": brand,
        "title": title,
    };
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'firebase_widget.dart';


class FirebaseExample extends StatefulWidget {
  const FirebaseExample({super.key});

  @override
  State<FirebaseExample> createState() => _FirebaseExampleState();
}

class _FirebaseExampleState extends State<FirebaseExample> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Firebase Data"),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>> //it has list of documents
      (
        stream: FirebaseFirestore.instance.collection("Products").snapshots(),
        builder: (context,snapshot) {
          if(snapshot.connectionState==ConnectionState.waiting){
            return const Center(child: CircularProgressIndicator());
          }
          if(snapshot.data==null || snapshot.hasError){
               return const Center(child:Text("data not available"));
          }
       //data can be null.

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context,index) {
          DocumentSnapshot doc1= snapshot.data!.docs[index];
         
          Map<String,dynamic> data = doc1.data() as Map<String,dynamic>;
              return Column(
                children: [
                  Center(child: Text(data['title'])),
                  Text(data['brand']),
                  Text('${data['Price']}'),
                  Text(data['Description']),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 2,
                      color: Colors.black)
                    ),
                    width: 150,
                    height: 150
                ,
                    child: GestureDetector
                    (
                      onTap: (){
                      // doc1.reference.update({"title":"New"});
                      // doc1.reference.delete();
                      
                    
                      
                      },
                      child: Image.network(data['Image']))),
                 SizeWidget(collectionReference: doc1.reference.collection("Size"),
                 data1:data,
                 length1: snapshot.data!.docs.length,
                  ),
                      const Divider(
                        height: 20,
                        thickness: 5,
                      )
                ],
              );
            }
          );
        }
      ),
    );
  }
}
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/employee_detail.dart';
import 'package:flutter_application_1/screens/booking.dart';
import 'package:flutter_application_1/services/employee_detail_service.dart';
import 'package:get/get.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  EmployeeService service3 = EmployeeService();

  //value assigned later to this variable
  EmployeeDetail? data2;
  bool loading = true;

  @override
  void initState() {
    getEmployeeDetail();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Image.asset(

          'assets/images/logo.jfif',
          fit: BoxFit.contain,
          height: 120,
          width: 100,
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: loading
                ? const Center(child: CircularProgressIndicator())
                : Column(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              width: 500,
              height: 30,
              color: Colors.yellow,
              child:const Text('NAVIGATOR - Lite'),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Flexible(flex: 1, fit: FlexFit.tight, child: SizedBox()),
                Flexible(
                  flex: 1,
                  fit: FlexFit.tight,
                  child: Center(
                    child: loading
                        ? const CircularProgressIndicator()
                        : CircleAvatar(
                            backgroundImage:
                                MemoryImage(base64Decode(data2!.data[0].photo)),
                            radius: 40,
                          ),
                  ),
                ),
                // SizedBox(width: 100,),
                // Image.asset('assets/images/SYNC.png',
                // width: 20,
                // height: 20,)
                Flexible(
                  flex: 1,
                  fit: FlexFit.tight,
                  child: IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.sync,
                      )),
                )
              ],
            ),
            // ClipRRect(child: Image.asset('assets/images/logo.jfif',
            // width: 100,
            // fit: BoxFit.fill,
            // height: 100,
            // color: Colors.red,
            // ),
            // borderRadius: BorderRadius.circular(100),
            // ),
            const SizedBox(
              height: 10,
            ),
            loading
                ? const CircularProgressIndicator()
                : Text(
                    data2!.data[0].name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),

            const SizedBox(
              height: 10,
            ),
            Text(
              data2!.data[0].cityName,
              style:const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            GestureDetector(
              onTap: (){

              },
              child: Container(
                width: 250,
                margin: const EdgeInsets.all(2),
                color: Colors.blue,
                child: TextButton(
                  onPressed: () {},
                  child:  const Text(
                    'Booking',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),

            GestureDetector(
              onTap: () {
                // Navigator.of(context).push(MaterialPageRoute(
                //   builder: (context) => Home1(empdetail1: data2!),
                // ));
                //this is due to Get material app.
                Get.to(()=>Home1(empdetail1: data2!));
                //button pr back jane k liye.
                // Get.back(); or navigator.pop for backtracking.
              },
              child: Container(
                margin: const EdgeInsets.all(2),
                width: 250,
                color: Colors.blue,
                child:  Center(
                  child: Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      'Bulk Booking',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {},
              child: Container(
                margin: const EdgeInsets.all(2),
                width: 250,
                color: Colors.blue,
                child: const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Center(
                    child: Text(
                      'Edit Booking',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: (){

              },
              child: Container(
                margin: const EdgeInsets.all(2),
                width: 250,
                color: Colors.blue,
                child: TextButton(
                  onPressed: () {},
                  child: const Text(
                    'Set Top Destinations',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: (){

              },
              child: Container(
                margin: const EdgeInsets.all(2),
                width: 250,
                color: Colors.blue,
                child: TextButton(
                  onPressed: () {},
                  child: const Text(
                    'Void CN',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: (){

              },
              child: Container(
                margin: const EdgeInsets.all(2),
                width: 250,
                color: Colors.blue,
                child: TextButton(
                  onPressed: () {},
                  child:  const Text(
                    'Manual CN Sequence',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: (){

              },
              child: Container(
                margin:  const EdgeInsets.all(2),
                width: 250,
                color: Colors.green,
                child: TextButton(
                  onPressed: () {},
                  child:  const Text(
                    'Summary',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            const  SizedBox(
              height: 30,
            ),
            Image.asset(
              'assets/images/colorbg.jfif',
              height: 50,
            ),
             const SizedBox(
              height: 50,
            ),
             const Text(
              'Powered By',
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
            ),
            const  Text(
              'Leopards Technology',
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
            ),
            const  Text(
              'Version: 1.18 - LIVE',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  void getEmployeeDetail() async {
    data2 = await service3.getEmployeeDetail();
    loading = false;
    setState(() {});
  }

  // super @override
  // void dispose() {

  //   super.dispose();
  // }
}

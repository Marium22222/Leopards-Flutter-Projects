import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/todos.dart';
import 'package:flutter_application_1/services/todos_service.dart';


class TodosScreen extends StatefulWidget {
  const TodosScreen({super.key});

  @override
  State<TodosScreen> createState() => _TodosScreenState();
}

class _TodosScreenState extends State<TodosScreen> {

  TodosService service1 = TodosService();
  List<Todos> data=[];

  @override
  void initState() {

    super.initState();
    getData();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(children: [
        Expanded(
          child: ListView.builder(
            itemBuilder: (context, index) {
              Todos todos2= data[index];
             return Padding(
               padding: const EdgeInsets.all(12.0),
               child: Container(
                height: 200,
                color: todos2.completed? Colors.green:Colors.red,
                margin:  const EdgeInsets.all(4),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                     const Icon(Icons.list),
                     const Text('TITLE'
                    ,
                    style: TextStyle(color: Colors.purple,
                    fontWeight: FontWeight.bold,
                    fontSize: 20 ),),
                    Text(todos2.title,
                    style:  const TextStyle(color: Colors.pink,
                    fontWeight: FontWeight.bold,
                    fontSize: 16 ),),
                    Text("${todos2.id}"),
                   

                  ],
                )),
             );
            },
            itemCount:data.length ,
          ),
        ),
        ]),
    );
  }


  void getData() async{
   data= await service1.getTodos();
   setState(() {
     
   });
  }
}
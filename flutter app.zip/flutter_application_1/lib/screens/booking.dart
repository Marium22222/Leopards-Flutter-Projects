
// ignore_for_file: prefer_interpolation_to_compose_strings

import 'package:flutter/material.dart';

import 'package:flutter_application_1/models/employee_detail.dart';
import 'package:flutter_application_1/models/services.dart';
import 'package:flutter_application_1/services/employee_detail_service.dart';

import 'package:flutter_application_1/widgets/dialog_screen.dart';

import '../models/accounts.dart';

class Home1 extends StatefulWidget {
  final EmployeeDetail empdetail1;

  const Home1({super.key, required this.empdetail1});
  @override
  State<Home1> createState() => _Home1State();
}

class _Home1State extends State<Home1> {
//late or question mark when value will arrive later.
  late Accounts? account1;
  EmployeeService service1 = EmployeeService();


  // List<String> list = <String>['Account #', 'option1', 'option2', 'option3'];
  late AccountDetails dropdownValue1;

  late ServicesDetail dropdownValue;
  late Services? service2;
  bool loading = true;
  int itemcount1= 0;

  // List<String> list = <String>[
  //   'O - OVERNIGHT',
  //   'option1',
  //   'option2',
  //   'option3'
  // ];
  // String dropdownValue = 'O - OVERNIGHT';

  final inputcontroller = TextEditingController();
  final inputcontroller1 = TextEditingController();

  @override
  void initState() {
    inputcontroller.text = "250";
    inputcontroller1.text = "0";
    super.initState();
    getAccounts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          'Corporate Booking',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
            color: Colors.black,
          ),
        ),
      ),
      body: LayoutBuilder(builder: (context, constraints) {
        return loading
            ? const CircularProgressIndicator()
            : Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Account #'),
                        Container(
                         margin: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                              color: Colors.blue,
                              border: Border.all(
                                  color: Colors.blue,
                                  style: BorderStyle.solid,
                                  width: 2)),
                          child: DropdownButton<AccountDetails>(
                          
                            
                            value: dropdownValue1,
                            icon: const Icon(Icons.arrow_drop_down_sharp),
                            elevation: 16,
                            dropdownColor: Colors.blue,
                            style: const TextStyle(color: Colors.deepPurple),
                            underline: Container(
                              height: 2,
                              color: Colors.blue,
                            ),
                            onChanged: (value1) {
                              //  This is called when the user selects an item.
                              setState(() {
                                dropdownValue1 = value1!;
                              });
                            },
                            items: account1!.data
                                .map<DropdownMenuItem<AccountDetails>>(
                                    (value1) {
                              return DropdownMenuItem<AccountDetails>(
                                value: value1,
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: constraints.maxWidth*0.3,
                                      child: Text(
                                        value1.clntName,
                                        style: const TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                          const SizedBox(
                      height: 2,
                    ),
                     Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                       const Text('Service'),
                        Container(
                    
                          decoration: BoxDecoration(
                              color: Colors.blue,
                              border: Border.all(
                                  color: Colors.blue,
                                  style: BorderStyle.solid,
                                  width: 2)),
                          child: DropdownButton<ServicesDetail>(
                            value: dropdownValue,
                            icon: const Icon(Icons.arrow_drop_down_sharp),
                            elevation: 16,
                            dropdownColor: Colors.blue,
                            style: const TextStyle(color: Colors.deepPurple),
                            underline: Container(
                              height: 2,
                              color: Colors.blue,
                            ),
                            onChanged: ( value) {
                              // This is called when the user selects an item.
                              setState(() {
                                //! meaning no null and ? means null allowed
                                dropdownValue = value!;
                              });
                            },
                            items: service2!.data
                                .map<DropdownMenuItem<ServicesDetail>>(( value) {
                              return DropdownMenuItem<ServicesDetail>(
                                value: value,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    value.code+'-'+value.shipmentType,
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                          const SizedBox(
                      height: 2,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Enter Weight in Grams'),
                        Container(
                          color: Colors.blue,
                          width: 100,
                          height: 50,
                          child: TextField(
                            textAlign: TextAlign.center,
                            style:const TextStyle(
                              color: Colors.white,
                            ),
                            controller: inputcontroller,
                            decoration: const InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(width: 3, color: Colors.blue),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                      const SizedBox(
                      height: 2,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('# of Shipments to Book'),
                        Container(
                          color: Colors.blue,
                          width: 100,
                          height: 50,
                          child: TextField(
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                            ),
                            onChanged: (value) {
                              itemcount1=int.parse(value);
                            },
                            controller: inputcontroller1,
                            decoration: const InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(width: 3, color: Colors.blue),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children:  const [
                         Text(
                          'KI000000507',
                          style:TextStyle(
                              color: Colors.deepPurple,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'Remaining CN(s):3',
                          style: TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontSize: 10),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                 itemcount1==0? Expanded(child: Center(child: Text("No shipments to show"))) 
                  : Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) => const DialogueScreen(),
                              );
                            },
                            child: Container(
                              margin: const EdgeInsets.all(10),
                              color: Colors.lightGreen,
                              height: 100,
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children:[
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                    Text(
                                        'KI000000507',
                                        style:TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15),
                                      ),
                                    Text(dropdownValue1.clntName)
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children:[
                                      Text('Destination'),
                                      Text(inputcontroller.text),
                                      Text('1'),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                        itemCount: int.parse(inputcontroller1.text),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    SizedBox(
                      width: constraints.maxWidth*0.9,
                      child: ElevatedButton(
                        onPressed: () {},
                        child: const Text('Save'),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {},
                          child: const Text('Select Pickup'),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: () {},
                          child: const Text('0 Booking Done'),
                        ),
                      ],
                    ),
                  ],
                ),
            );
      }),
    );
  }

  void getAccounts() async {
    //widget used bcoz empdetail1 called from other class.
    account1 = await service1.getAccounts(widget.empdetail1.data[0].cityId);
    dropdownValue1 = account1!.data[0];
    service2 =await service1.getServices();
    dropdownValue =service2!.data[0];
    loading = false;
    setState(() {});
  }
}

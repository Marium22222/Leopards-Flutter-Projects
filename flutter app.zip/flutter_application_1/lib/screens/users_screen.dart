import 'package:flutter/material.dart';

import 'package:flutter_application_1/services/users_service.dart';
import 'package:flutter_application_1/widgets/dialog_screen2.dart';
import 'package:flutter_application_1/models/users.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  UsersService service2 = UsersService();
  List<Users> data1=[];
  @override
  void initState() {
    getData();

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.amber[700],
        title: const Text('All Leads'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
           color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: const [
                  Icon(Icons.search),
                  SizedBox(width: 20,),
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(

                        hintText: 'Search'
                      ),
                    ),
                  )
                ],
              ),
            ),

          ),
          Expanded(
            child: ListView.builder(itemBuilder: (context, index) {
              Users user2=data1[index];
              return InkWell(
                onTap:  () {
                  showDialog(
                    context: context,
                    builder: (context)=>DialogueScreen2(
                    username: user2.username,
                      email: user2.email,
                      website: user2.website,
                        phone:user2.phone,
                      street:user2.address.street,
                      city:user2.address.city,
                      name:user2.name,
                      id:user2.id,

                  ),);
                },
                child: Container(
                  color: Colors.amber[700],
                  child: Padding(

                    padding: const EdgeInsets.all(8.0),
                    child: Container(

                       height: 200,
                    decoration: BoxDecoration(color: Colors.deepPurpleAccent[100],
                      border: Border.all(color: Colors.purple,
                        width: 5

                  ),),
                      child: Row(

                        children: [
                             // Text('User${user2.id}',
                             // style: TextStyle(fontWeight: FontWeight.bold,
                             // color: Colors.white,
                             // fontSize: 20),),
                          Column(
                             mainAxisAlignment: MainAxisAlignment.center,
                             children: [

                            Row(

                              children: [
                                 const SizedBox(width: 30,),
                                Stack(
                                  children:[
                                    Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    color: Colors.black,
                                    border: Border.all(color: Colors.white,
                                    width: 5)
                                  ),
                                ),
                                const Positioned(
                                  top: 10,
                                  left: 10,
                                  right: 10,
                                  bottom: 10,
                                  child:
                                   SizedBox(
                                    width: 40,
                                    height: 40,

                                    child: CircleAvatar(
                                      backgroundImage: AssetImage('assets/images/user1.jpg'),
                                      radius: 20,
                                    ),
                                  ),),],),
                                 const SizedBox(width: 50,),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [

                                    const  Icon(Icons.person,
                                    color: Colors.purpleAccent,),
                                     Text(user2.name,
                                    style:  const TextStyle(fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white
                                    ),),
                                     const SizedBox(height: 10,),
                                     const Icon(Icons.email,

                                        color: Colors.purpleAccent),
                                    Text(user2.email,
                                    style:  const TextStyle(
                                      color: Colors.white
                                    ),),
                                       const SizedBox(height: 10,),
                                     const Icon(Icons.phone,

                                        color: Colors.purpleAccent),
                                    Text(user2.phone,
                                      style:  const TextStyle(
                                          color: Colors.white
                                      ),),
                                  ],
                                ),

                              ],
                            ),
                          ]),
                        ],
                      ),
                    ),
                  ),
                ),
              );

            },
            itemCount: data1.length,

            ),
          ),
        ],
      ),
    );
  }
  void getData() async{
    data1=await service2.getUsers();
    setState(() {

    });
  }

}